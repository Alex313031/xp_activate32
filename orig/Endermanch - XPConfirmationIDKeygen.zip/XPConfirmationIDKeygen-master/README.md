# XPConfirmationIDKeygen

![Confirmation ID Keygen](https://github.com/Endermanch/XPConfirmationIDKeygen/assets/44542704/0333498a-c347-4580-ba54-f2a12754e152)

POC Source code for the XP Confirmation ID that uses hyperelliptic curves.
I attempted to reverse engineer this program quite some time ago, thankfully the source code was leaked.

![Keygen](https://github.com/Endermanch/XPConfirmationIDKeygen/assets/44542704/44d8d277-9b00-447f-bc45-dc65ce604790)
![IDA](https://github.com/Endermanch/XPConfirmationIDKeygen/assets/44542704/07277e27-9459-4c5b-af0c-6dbb17cd66c4)

**This isn't the cleanest code and looks like somebody else's disassembly work**. Let me know in the issues if you're the author of this god's work.
By the way, reversing virtual methods is abysmal.

**TODO: Cleanup the code.**
Compiled using v141_xp toolset, check releases for the executable.

Found by https://github.com/thepwrtank18, uploaded to archive.org here: https://archive.org/details/xp_activate32_src
Shoutout to [Neo-Desktop](https://github.com/Neo-Desktop) and enthusiasts [here](https://github.com/Neo-Desktop/WindowsXPKg/issues/1)!
