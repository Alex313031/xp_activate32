from pyntl.ellipticcurve import *
from pyntl.numbertheory import *
from pyntl.ecdlp import *

if __name__ == '__main__':
    GF = FiniteField(416363315556156604917983573)
    E = EllipticCurve(GF,3881733152902215205506458208,121489936031066440060440631)
    G = E(232349146313044524685417226,8425515734129553132973322)
    K = E(268507436745473388067569197,51099634945595802171100073)
    FactoredOrder= [(416363315556124458285894983,1)]
    print("The solution is:",ecdlp_solve(G,K,FactoredOrder,"id"))
    input("press enter to exit")
