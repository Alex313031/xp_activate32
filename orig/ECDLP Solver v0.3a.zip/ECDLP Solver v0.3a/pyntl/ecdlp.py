from pyntl.numbertheory import *
from pyntl.ellipticcurve import *
import time,random,array,os,hashlib,platform,sys
from ctypes import *
from multiprocessing import *

USE_CUDA_GPU = False

def bruteforce(G,K,Order):
    T=G
    for result in range(1,Order+1):
        if T==K: return result
        else: T+=G
    raise ValueError

def rho_worker(queue,id,G,K,Order,GpuArchitecture=None):
    Subgroup=FiniteField(Order)
    EC=G.ec
    suffix=""
    if not GpuArchitecture is None:
        suffix=" "+GpuArchitecture;
    #library=platform.system()+"/"+str(sizeof(c_void_p)*8)+"bit"+"/ECDLP Solver Library"+suffix
    driver=cdll.LoadLibrary(platform.system()+"/"+str(sizeof(c_void_p)*8)+"bit"+"/ECDLP Solver Library"+suffix)
    driver.gfp_create(c_char_p(format(EC.ff.get_prime(),"X")))
    driver.ecp_create(c_char_p(format(EC.a,"X")),c_char_p(format(EC.b,"X")))
    driver.rho_create(c_char_p(id),c_char_p(format(G.x,"X")),c_char_p(format(G.y,"X")),c_char_p(format(K.x,"X")),c_char_p(format(K.y,"X")),c_char_p(format(Order,"X")))
    instance=c_void_p()
    driver.rho_init(byref(instance))
    c_relation=(create_string_buffer(driver.gfp_get_str_len()),create_string_buffer(driver.gfp_get_str_len()),create_string_buffer(driver.gfp_get_str_len()),create_string_buffer(driver.gfp_get_str_len()))
    while True:
        driver.rho_next_relation(instance,c_relation[0],c_relation[1],c_relation[2],c_relation[3])
        x=(Subgroup(to_int(c_relation[0])),Subgroup(to_int(c_relation[1])))
        X=str(EC(to_int(c_relation[2]),to_int(c_relation[3])))
        queue.put((X,x))
    
def rho(id,G,K,Order):
    print("Initializing ecdlp solver server")
    Subgroup=FiniteField(Order)
    EC=G.ec
    lookup={}
    G.normalize()
    K.normalize()
    print("G: "+str(G))
    print("K: "+str(K))
    file_name=id+"_"+hashlib.md5(bytes(str(EC)+"_"+str(G)+"_"+str(K),"ascii")).hexdigest()+".txt"
    if os.path.exists(file_name):
        in_file = open(file_name, "r")
        while True:
            in_line = in_file.readline()
            if not in_line: break
            if in_line=="\n": continue
            in_line = in_line[:-1]
            X, x0, x1 = in_line.split(":")
            if X in lookup:
                in_file.close()
                return int((lookup[X][0]-Subgroup(int(x0,10)))/(Subgroup(int(x1,10))-lookup[X][1]))
            else:
                lookup[X] = (Subgroup(int(x0,10)),Subgroup(int(x1,10)))
        in_file.close()
    out_file=open(file_name,"a")
    out_file.write("\n")
    queue=Queue()
    
    #rho_worker(queue,id,G,K,Order,"CUDA")
    if USE_CUDA_GPU:
        for i in range(0,cpu_count()-1):
            Process(target=rho_worker,args=(queue,id,G,K,Order)).start()
        Process(target=rho_worker,args=(queue,id,G,K,Order,"CUDA")).start()
    else:
        for i in range(0,cpu_count()):
            Process(target=rho_worker,args=(queue,id,G,K,Order)).start()
            
    seconds=time.time()
    while True:
        if not queue.empty():
            (X,x)=queue.get()
            out_file.write(X+":"+str(x[0])+":"+str(x[1])+"\n")
            out_file.flush()
            if X in lookup:
                out_file.close()
                for w in active_children(): w.terminate()
                print("\nFinalizing ecdlp solver server")
                return int((lookup[X][0]-x[0])/(x[1]-lookup[X][1]))
            else:
                lookup[X]=x
        else:
            time.sleep(0.5)
            if len(active_children())==0:
                out_file.close()
                raise AssertionError("No active workers!")
            print("Time: +"+str(int(time.time()-seconds))+" seconds, Relations: "+str(len(lookup))+"\r",end="")
            time.sleep(0.5)
            
def ecdlp_solve(G,K,FactoredOrder,id):
    #Verify Order
    Order=1
    for e in FactoredOrder: Order*=e[0]**e[1]
    assert Order*G==Order*K==0
    
    lookup={}
    if os.path.exists(id+".txt"):
        in_file = open(id+".txt", "r")
        while True:
            in_line = in_file.readline()
            if not in_line: break
            if in_line=="\n": continue
            in_line = in_line[:-1]
            Q, R, c = in_line.split(":")
            lookup[(Q,R)] = int(c)
        in_file.close()
    out_file=open(id+".txt",'a')
    relations=[]
    for e in FactoredOrder:
        remainder=0
        Q=G*(Order//e[0])
        Rj=K
        for j in range(e[1]):
            R=Rj*(Order//(e[0]**(j+1)))
            if (str(Q),str(R)) in lookup:
                c=lookup[(str(Q),str(R))]
            else:
                if e[0]<1024: c=bruteforce(Q,R,e[0])
                else: c=rho(id,Q,R,e[0])
                out_file.write(str(Q)+":"+str(R)+":"+str(c)+"\n")
                out_file.flush()
            Rj=Rj-G*(c*(e[0]**j))
            remainder+=c*(e[0]**j)
        relations.append((e[0]**e[1],remainder))
    out_file.close()
    return crt(relations)

def to_int(char_array):
    return int(repr(char_array.value).lstrip("b'").rstrip("'"),16)
