def invert(value,prime):
    if value==0: raise ZeroDivisionError
    a,b=value,prime
    x,inverse = 0,1
    while b != 0:
        a,b,q =b,a % b, a // b
        x,inverse = inverse-q*x,x
    return inverse

def crt(relations):
    result=0
    n=1
    for relation in relations:
        n*=relation[0]
    for relation in relations:
        result+=relation[1]*(n//relation[0])*invert((n//relation[0]),relation[0])
    return result % n