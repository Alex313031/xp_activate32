class FiniteField:
    def __init__(self,prime):
        assert prime>1
        self.__prime=prime
    def __str__(self):
        return "Finite Field Modulo " + str(self.__prime)
    def get_prime(self):
        return self.__prime
    def __call__(self,value):
        return FiniteFieldElement(self,value)
    def map(self,value):
        return value % self.__prime
    def invert(self,value):
        if value==0: raise ZeroDivisionError
        a,b=value,self.__prime
        x,inverse = 0,1
        while b != 0:
            a,b,q =b,a % b, a // b
            x,inverse = inverse-q*x,x
        return inverse
    def pow(self,value,exponent):
        if exponent<0:
            value,exponent=self.invert(value),-exponent
        return pow(value,exponent,self.__prime)
    def negate(self,value):
        return (-value) % self.__prime
    
class FiniteFieldElement:
    def __init__(self,ff,value):
        self.__ff=ff
        if type(value) is int:
            self.__value=ff.map(value)
        elif type(value) is FiniteFieldElement:
            self.__value=ff.map(value.__value)
    def __str__(self): 
        return str(self.__value)
    def __index__(self):
        return self.__value
    def __int__(self):
        return self.__value
    def __format__(self,format_spec):
        return format(self.__value,format_spec)
    def __eq__(self,other):
        if type(other) is int:
            if other==0 or other==1: return self.__value==other
            else: raise NotImplementedError
        return self.__value==other.__value
    def __add__(self,other): 
        return FiniteFieldElement(self.__ff,self.__value+other.__value)
    def __sub__(self,other): 
        return FiniteFieldElement(self.__ff,self.__value-other.__value)
    def __neg__(self):
        return FiniteFieldElement(self.__ff,self.__ff.negate(self.__value))
    def __pow__(self,other):
        return FiniteFieldElement(self.__ff,self.__ff.pow(self.__value,other))
    def __mul__(self,other): 
        return FiniteFieldElement(self.__ff,self.__value*other.__value)
    def __invert__(self): 
        return FiniteFieldElement(self.__ff,self.__ff.field_invert(self.__value))
    def __div__(self,other): 
        if (other==1): return FiniteFieldElement(self.__ff,self.__value)
        return FiniteFieldElement(self.__ff,self.__value*self.__ff.invert(other.__value))
    def __truediv__(self,other):
        if (other==1): return FiniteFieldElement(self.__ff,self.__value)
        return FiniteFieldElement(self.__ff,self.__value*self.__ff.invert(other.__value))
    def __floordiv__(self,other):
        if (other==1): return FiniteFieldElement(self.__ff,self.__value)
        return FiniteFieldElement(self.__ff,self.__value*self.__ff.invert(other.__value))
        
