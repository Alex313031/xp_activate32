from pyntl.finitefield import *

class EllipticCurve:
    def __init__(self,ff,a,b):
        self.ff=ff
        self.a,self.b=FiniteFieldElement(self.ff,a),FiniteFieldElement(self.ff,b)
    def __call__(self,*args):
        assert 0 <= len(args) <= 3
        if len(args)==0: return EllipticCurveElement(self,0,1,0)
        elif len(args)==1: raise NotImplementedError
        elif len(args)==2: return EllipticCurveElement(self,args[0],args[1],1)
        elif len(args)==3: return EllipticCurveElement(self,args[0],args[1],args[2])
    def __str__(self):
        return "Elliptic Curve defined by y^2 = x^3 + "+str(self.a)+"*x + "+str(self.b)+" over "+str(self.ff)
    def isElement(self,x,y,z):
        return (y*y*z)==(x*x*x+self.__a*x*z*z+self.__b*z*z*z)

class EllipticCurveElement:
    def __init__(self,ec,x,y,z):
        self.ec=ec
        self.x,self.y,self.z=ec.ff(x),ec.ff(y),ec.ff(z)
    def normalize(self):
        if self.z==0 or self.z==1: return
        else:
            self.x,self.y,self.z=self.x/self.z,self.y/self.z,self.ec.ff(1)
    def __str__(self):
        if self.z==0: return "[0,1,0]"
        elif self.z==1: return "["+str(self.x)+","+str(self.y)+",1]"
        else: return "["+str(self.x/self.z)+","+str(self.y/self.z)+",1]"
    def __format__(self,format_spec):
        if self.z==0: return "[0,1,0]"
        else: return "["+format(self.x/self.z,format_spec)+","+format(self.y/self.z,format_spec)+",1]"
    def __eq__(self,other):
        if type(other) is int:
            if other==0: return self.x==0 and self.z==0
            else: raise NotImplementedError
        return self.x*other.z==other.x*self.z and self.y*other.z==other.y*self.z
    def __neg__(self):
        return self.ec(self.x,-self.y,self.z)
    def __add__(self,other):
        if self==0: return self.ec(other.x,other.y,other.z)
        elif other==0: return self.ec(self.x,self.y,self.z)
        elif self==-other: return self.ec()
        elif self==other: return self.double()
        Y1Z2=self.y*other.z
        X1Z2=self.x*other.z
        Z1Z2=self.z*other.z
        u=other.y*self.z-Y1Z2
        uu=u*u
        v=other.x*self.z-X1Z2
        vv=v*v
        vvv=v*vv
        R=vv*X1Z2
        A=uu*Z1Z2-vvv-R-R
        return self.ec(v*A,u*(R-A)-vvv*Y1Z2,vvv*Z1Z2)
    def double(self):
        if self==0: return self.ec()
        XX=self.x*self.x
        ZZ=self.z*self.z
        w=self.ec.a*ZZ+XX+XX+XX
        s=self.y*self.z
        s=s+s
        ss=s*s
        sss=s*ss
        R=self.y*s
        RR=R*R
        B=(self.x+R)*(self.x+R)-XX-RR
        h=w*w-B-B
        return self.ec(h*s,w*(B-h)-RR-RR,sss)
    def __mul__(self,other):
        assert type(other) is int
        result=self.ec()
        for i in bin(other).lstrip('-0b'):
            result=result.double()
            if i=='1': result+=self
        return result
    def __rmul__(self,other):
        return self*other
    def __sub__(self,other):
        return self+-other
